import os, sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from classes.fenetre import Fenetre
from classes.controleur import Controleur
from classes.amas import Amas
from threading import Thread
from time import sleep

fenetre = Fenetre("Philosophers example")
amas = Amas()
controleur = Controleur(fenetre,amas)

"""
Fonction de thread pour simuler le problème des fourmis
"""
def action():
    widthCanvas = fenetre.get_canvas_width()
    heightCanvas = fenetre.get_canvas_height()
    ants = []
    for i in range (10):
        ant = controleur.draw_image(20+(i*100), 20, 'images/ant.png')
        ants.append(ant)

    leaf = controleur.draw_image(widthCanvas-300, heightCanvas-50, 'images/leaf.png')

    for i in range (1000):
        for j in range (10):
            coords_ant = controleur.get_coords_image(ants[j])
            controleur.move_image(ants[j], coords_ant[0], coords_ant[1]+5)
            sleep(0.05)

def main():
    th = Thread(target=action).start()
    controleur.get_fenetre().display()

main()
