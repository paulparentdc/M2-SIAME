from pyAmakIHM.classes.fenetre import Fenetre
from pyAmakIHM.classes.controleur import Controleur
from pyAmakIHM.classes.amas import Amas
from threading import Thread

fenetre = Fenetre("Test Amas")
amas = Amas()
controleur = Controleur(fenetre,amas)

def main():
    th = Thread(target=amas.cycle).start()
    fenetre.display()

main()
