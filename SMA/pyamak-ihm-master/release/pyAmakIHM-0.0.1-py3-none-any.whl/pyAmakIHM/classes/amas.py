from time import sleep
class Amas:
    def __init__(self):
        self.agents = []
        self.sleep = 1
        self.__observer = None

    def attach(self,observer):
        self.__observer = observer

    def notifyObserver(self,value):
        self.__observer.updateCycle(value)

    def add_agent(self,name):
        self.agents.append(name)

    def remove_agent(self):
        del self.agents[len(self.agents)-1]

    def reset(self):
        self.agents = []

    def set_speed(self,value):
        self.sleep = value

    def cycle(self):
        while (True):
            for i in range (len(self.agents)):
                print('Je suis le numéro %d' % i)
            sleep(10 / self.sleep)
            self.notifyObserver(self.sleep)
