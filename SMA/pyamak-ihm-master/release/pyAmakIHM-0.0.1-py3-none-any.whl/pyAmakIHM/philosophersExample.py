from pyAmakIHM.classes.fenetre import Fenetre
from pyAmakIHM.classes.controleur import Controleur
from pyAmakIHM.classes.amas import Amas
from threading import Thread
from time import sleep
from math import cos,sin,pi
from random import randint

fenetre = Fenetre("Philosophers example")
amas = Amas()

controleur = Controleur(fenetre,amas)

"""
Fonction de thread pour simuler le problème des philosophes
"""
def action():
    numbreCycle = 10
    numberPhilosopher = 10
    widthCanvas = fenetre.get_canvas_width()
    heightCanvas = fenetre.get_canvas_height()
    philosophers = []

    #Init
    controleur.setTitle('Eaten Pastas')
    controleur.setXLabel('Philosophers')
    controleur.setYLabel('Number of eaten pastas')
    for i in range (numberPhilosopher):
        x = 100 * cos(2 * pi * i / numberPhilosopher) + (widthCanvas/2)
        y = 100 * sin(2 * pi * i / numberPhilosopher) + (heightCanvas/2)
        carre = controleur.draw_rectangle(x,y,20,20,'green')
        philosophers.append(carre)

        nom = 'Mr ' + str(i)
        controleur.addColumn(nom)
        controleur.setValue(i, x)

    sleep(5)

    #Simulation
    for i in range (numbreCycle):
        for j in range (numberPhilosopher):
            controleur.increaseValue(j, 1)
            choix = randint(0, 2)
            if(choix == 0):
                controleur.change_color(philosophers[j], 'green')

            elif(choix == 1):
                controleur.change_color(philosophers[j], 'red')

            else:
                controleur.change_color(philosophers[j], 'blue')

        sleep(2)

def main():
    th = Thread(target=action).start()
    controleur.get_fenetre().display()

main()
