"""
test that Mail work as intended
"""
from unittest import TestCase, main

from pyAmakCore.classes.communicating_agent import Mail


class TestMail(TestCase):
    """
    Test class Mail
    """

    def test_mail(self) -> None:
        """
        Test mail init
        """
        mail = Mail(1, 5, None)

        self.assertEqual(mail.get_id_sender(), 1)
        self.assertEqual(mail.get_id_receiver(), 5)
        self.assertEqual(mail.get_message(), None)

        mail = Mail(255, 0, "test")
        self.assertEqual(mail.get_id_sender(), 255)
        self.assertEqual(mail.get_id_receiver(), 0)
        self.assertEqual(mail.get_message(), "test")


if __name__ == '__main__':
    main()
