"""
Warning for the methods which must be override
"""


class ToOverrideWarning:
    """
    Warning raised a method that should be override is called
    """

    def __init__(
            self,
            name: str
    ) -> None:
        # print("[WARNING] : Method " + name + " was called without being override.")
        pass
