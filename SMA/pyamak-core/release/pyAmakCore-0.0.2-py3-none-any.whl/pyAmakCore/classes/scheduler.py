"""
Scheduler class
"""
from threading import Semaphore, Thread
from time import sleep
from typing import List
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.classes.schedulable import Schedulable


class Scheduler():
    """
    Scheduler class, to make sure that environment and amas are always sync together
    """

    def __init__(self) -> None:

        # List of all schedulables
        self.__schedulables: List[Schedulable] = []
        # Sleep timer between 2 cycle
        self.sleep_time: float = 0

        # Semaphore for start/stop button
        self.__semaphore_start_stop: Semaphore = Semaphore(0)
        # Semaphore to tell amas to continue
        self.__semaphore_amas: Semaphore = Semaphore(0)
        # Semaphore to tell environment to continue
        self.__semaphore_environment: Semaphore = Semaphore(0)

        self.exit_bool = False

    def add_schedulable(self, schedulable: Schedulable) -> None:
        """
        add schedulable in schedulables list
        """
        self.__schedulables.append(schedulable)

    def take_amas_token(self) -> None:
        """
        make amas wait here for a token
        """
        self.__semaphore_amas.acquire()

    def give_amas_token(self) -> None:
        """
        unlock amas
        """
        self.__semaphore_amas.release()

    def take_environment_token(self) -> None:
        """
        make environment wait here for a token
        """
        self.__semaphore_environment.acquire()

    def give_environment_token(self) -> None:
        """
        unlock environment
        """
        self.__semaphore_environment.release()

    def take_semaphore_start_stop(self) -> None:
        """
        Scheduler will wait for a token to start the cycle
        """
        self.__semaphore_start_stop.acquire()

    def give_semaphore_start_stop(self) -> None:
        """
        give a token to unlock Scheduler
        """
        self.__semaphore_start_stop.release()

    def syncro_schedulable(self) -> None:
        """
        wait for all schedulable to release a token
        """
        for schedulable in self.__schedulables:
            schedulable.take_token_syncro()

    def run(self) -> None:
        """
        main part of amak core
        """
        # wait that all schedulable are ready
        self.syncro_schedulable()

        while not self.exit_bool:

            self.__semaphore_start_stop.acquire()
            self.__semaphore_start_stop.release()

            threads = []
            for schedulable in self.__schedulables:
                current_thread = Thread(target=schedulable.run)
                threads.append(current_thread)
                current_thread.start()

            # on cycle begin
            self.syncro_schedulable()
            self.give_amas_token()
            self.give_environment_token()

            # main part of the cycle
            self.syncro_schedulable()
            self.give_amas_token()
            self.give_environment_token()

            # on cycle end

            for thread in threads:
                thread.join()

            sleep(self.sleep_time)
