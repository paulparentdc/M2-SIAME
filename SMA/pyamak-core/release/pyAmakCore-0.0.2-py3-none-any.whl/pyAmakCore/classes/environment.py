"""
Environment class
"""
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.classes.schedulable import Schedulable
from pyAmakCore.classes.scheduler import Scheduler


class Environment(Schedulable):
    """
    Environment class
    """

    def __init__(self) -> None:
        super().__init__()
        self.scheduler: Scheduler = None
        self.on_initialization()
        # tell scheduler that init is done
        self.give_token_syncro()

    def add_scheduler(self, scheduler: Scheduler) -> None:
        """
        set scheduler pointer to scheduler
        add add self to schedulables of scheduler
        """
        self.scheduler = scheduler
        self.scheduler.add_schedulable(self)

    def synchronization(self) -> None:
        """
        Unlock Scheduler and wait for his response
        """
        self.give_token_syncro()
        self.scheduler.take_environment_token()

    def cycle(self) -> None:
        """
        Main behavior of Environment
        """
        self.on_cycle_begin()
        self.synchronization()

        # mileu de cycle
        self.synchronization()

        self.on_cycle_end()
