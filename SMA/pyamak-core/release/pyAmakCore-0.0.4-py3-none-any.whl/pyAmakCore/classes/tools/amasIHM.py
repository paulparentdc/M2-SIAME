"""
Amas class that need to be used for pyAmakIhm
"""
from pyAmakCore.classes.amas import Amas
from pyAmakCore.classes.environment import Environment


class AmasIHM(Amas):
    """
    Convenient class to override while using pyAmakIHM
    """

    def __init__(self, environment: Environment):
        self.__observer = None
        super().__init__(environment)

    def get_Agents_Sorted(self):
        """
        sort agent by id
        """
        agents = self.get_agents()
        agents.sort(key=lambda x: x.get_id())
        return agents

    def cycle(self) -> None:
        """
        override amas cycle, to update obsever after each cycle
        """
        super().cycle()
        self.__observer.updateCycle(self.get_environment(), self)

    def attach(self, observer: 'Controleur') -> None:
        """
        set observer pointer to observer
        """
        self.__observer = observer
