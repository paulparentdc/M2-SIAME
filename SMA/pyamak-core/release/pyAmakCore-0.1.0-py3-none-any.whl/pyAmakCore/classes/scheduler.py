"""
Scheduler class
"""
import sys
import pathlib
import pickle
from threading import Semaphore, Thread
from time import sleep

sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.classes.amas import Amas
from pyAmakCore.classes.scheduler_tool.schedulable_thread import SchedulableThread
from pyAmakCore.classes.scheduler_tool.amas_thread import AmasThread


class Scheduler:
    """
    Scheduler class, to make sure that environment and amas are always sync together
    """

    def __init__(self, amas: Amas) -> None:
        self.amas: Amas = amas

        self.exit_bool = False

        self.semaphore_start_stop = Semaphore(0)

        self.schedulables = []
        self.schedulables_threads = []

        self.add_schedulables(amas, AmasThread)
        self.add_schedulables(amas.get_environment(), SchedulableThread)

        self.sleep_time = 0

    def get_amas(self):
        return self.amas

    def add_schedulables(self, schedulable, cls):
        schedulable_thread = cls(schedulable)
        self.schedulables.append(schedulable_thread)
        current_thread = Thread(target=schedulable_thread.run)
        self.schedulables_threads.append(current_thread)
        current_thread.start()

    def wait_schedulables(self) -> None:
        """
        wait for all schedulable to release a token
        """
        for schedulable in self.schedulables:
            schedulable.action_done.acquire()

    def start_schedulables(self) -> None:
        """
        wait for all schedulable to release a token
        """
        for schedulable in self.schedulables:
            schedulable.is_waiting.release()

    def first_part(self) -> None:
        """
        first part of a cycle
        """
        self.start_schedulables()
        # on cycle begin
        self.wait_schedulables()

    def main_part(self) -> None:
        """
        main part of a cycle
        """
        self.start_schedulables()
        # agent cycle
        self.wait_schedulables()

    def last_part(self) -> None:
        """
        last part of a cycle
        """
        self.start_schedulables()
        # on cycle end
        self.wait_schedulables()

    def run(self) -> None:
        """
        main part of amak core
        """
        while not self.exit_bool:
            print("Cycle : ", self.amas.get_cycle())

            self.semaphore_start_stop.acquire()
            if self.exit_bool:
                break
            self.semaphore_start_stop.release()

            self.first_part()
            self.main_part()
            self.last_part()

            sleep(self.sleep_time)
        self.close_childs()

    def close_childs(self):
        for schedulable in self.schedulables:
            schedulable.exit_bool = True
            schedulable.is_waiting.release()
        for thread in self.schedulables_threads:
            thread.join(0)

    """
    program interface
    """

    def exit_program(self):
        self.exit_bool = True
        self.semaphore_start_stop.release()

    def start(self):
        self.semaphore_start_stop.release()

    def stop(self):
        self.semaphore_start_stop.acquire()

    def set_sleep(self, sleep_time: int):
        self.sleep_time = sleep_time

    """
    load & save program
    """

    def save(self):
        with open('filename.pickle', 'wb') as handle:
            pickle.dump(self.amas, handle, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls):
        with open('filename.pickle', 'rb') as handle:
            amas_object = pickle.load(handle)

        return cls(amas_object)

