"""
Environment class
"""
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.classes.tools.schedulable import Schedulable


class Environment(Schedulable):
    """
    Environment class
    """

    def __init__(self) -> None:
        super().__init__()
        self.on_initialization()
