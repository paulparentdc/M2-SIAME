"""
Savable Class
"""
import pickle
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.classes.amas import Amas


class Savable:
    """
    Class that implement convenient method to save and load an amas
    """
    def __init__(self, amas: Amas) -> None:
        self.amas = amas

    def get_amas(self):
        """
        return amas
        """
        return self.amas

    def save(self) -> None:
        """
        Save the current state of the system
        """
        with open('filename.pickle', 'wb') as handle:
            pickle.dump(self.amas, handle, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls) -> 'Savable':
        """
        Load the last save of the system
        """
        with open('filename.pickle', 'rb') as handle:
            amas_object = pickle.load(handle)

        return cls(amas_object)