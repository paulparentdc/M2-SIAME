"""
class Callable
"""
from threading import Semaphore


class Callable:
    """
    Class that implement useful method to interact with the program
    """

    def __init__(self) -> None:
        self.exit_bool: bool = False
        self.sleep_time: float = 0

        self.semaphore_start_stop: Semaphore = Semaphore(0)

    def exit_program(self) -> None:
        """
        Exit the system as soon as possible
        """
        self.exit_bool = True
        self.semaphore_start_stop.release()

    def start(self) -> None:
        """
        Unlock the scheduler
        """
        self.semaphore_start_stop.release()

    def stop(self) -> None:
        """
        Lock the scheduler
        """
        self.semaphore_start_stop.acquire()

    def set_sleep(self, sleep_time: int) -> None:
        """
        Set sleep value between 2 cycles
        """
        self.sleep_time = sleep_time
