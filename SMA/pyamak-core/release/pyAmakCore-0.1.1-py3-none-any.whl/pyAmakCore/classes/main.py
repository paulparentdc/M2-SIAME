from pyAmakCore.classes.communicating_agent import CommunicatingAgent

from pyAmakCore.exception.override import ToOverrideWarning
from pyAmakCore.classes.agent import Agent
from pyAmakCore.classes.amas import Amas
from pyAmakCore.classes.environment import Environment
from pyAmakCore.classes.scheduler import Scheduler


class SimpleAgent(Agent):
    """
    test
    """
    def __init__(self, amas):
        super().__init__(amas)

        self.i = 0

    def on_cycle_begin(self) -> None:
        self.i += 1


class SimpleAmas(Amas):
    """
    test
    """

    def on_initial_agents_creation(self) -> None:
        for i in range(10):
            self.add_agent(SimpleAgent(self))


class SimpleEnv(Environment):
    """
    test
    """

class SimpleAgent2(CommunicatingAgent):
    """
    test
    """

env = SimpleEnv()
amas = SimpleAmas(env)

agent = SimpleAgent2(amas)
print(isinstance(agent, CommunicatingAgent))


import time
start_time = time.time()
ToOverrideWarning.enable_warning(False)

env = SimpleEnv()
amas = SimpleAmas(env)

scheduler = Scheduler(amas)

scheduler.start()
scheduler.run()
print("--- %s seconds ---" % (time.time() - start_time))
