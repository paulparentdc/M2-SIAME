"""
Schedulable interface
"""
from threading import Semaphore
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from pyAmakCore.exception.override import ToOverrideWarning


class Schedulable:
    """
    Class Schedulable
    """
    syncro_semaphore: Semaphore = Semaphore(0)

    def on_initialization(self) -> None:
        """
        This method will be executed at the end of __init__()
        """
        ToOverrideWarning("on_initialization")

    def on_cycle_begin(self) -> None:
        """
        This method will be executed at the start of each cycle
        """
        ToOverrideWarning("on_cycle_begin")

    def on_cycle_end(self) -> None:
        """
        This method will be executed at the end of each cycle
        """
        ToOverrideWarning("on_cycle_end")

    def run(self) -> None:
        """
        Method that will be called by the thread
        """
        self.cycle()

    def cycle(self) -> None:
        """
        Main behavior of the Schedulable
        """
        ToOverrideWarning("cycle")

    def take_token_syncro(self) -> None:
        """
        Scheduler will wait here that the schedulable release a token
        """
        self.syncro_semaphore.acquire()

    def give_token_syncro(self) -> None:
        """
        Unlock thread_tool
        """
        self.syncro_semaphore.release()
