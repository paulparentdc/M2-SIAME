from setuptools import find_packages, setup

setup(
    name='pyAmakIHM',
    packages=find_packages(),
    version='0.0.1',
    description='Test',
    author='BE',
    install_requires=[],
)
