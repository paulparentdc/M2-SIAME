"""
test that run of Agent work as intended
"""
from unittest import TestCase, main

from pyAmakCore.classes.agent import Agent
from pyAmakCore.classes.amas import Amas
from pyAmakCore.classes.environment import Environment
from pyAmakCore.enumeration.agent_phase import Phase
from pyAmakCore.enumeration.executionPolicy import ExecutionPolicy


class TestAgentRun(TestCase):
    """
    Test class for Agent run
    """

    def test_run_one_phase(self):
        """
        test that run() work and return correct phase with 1 phase policy
        """
        Agent.reset_agent()
        environment = Environment()
        amas = Amas(environment)
        amas.set_execution_policy(ExecutionPolicy.ONE_PHASE)

        agent = Agent(amas)
        self.assertEqual(agent.get_phase(), Phase.INITIALIZING)
        agent.run()
        self.assertEqual(agent.get_phase(), Phase.DECISION_AND_ACTION_DONE)
        agent.run()
        self.assertEqual(agent.get_phase(), Phase.DECISION_AND_ACTION_DONE)

    def test_run_two_phase(self):
        """
        test that run() work and return correct phase with 2 phase policy
        """
        Agent.reset_agent()
        environment = Environment()
        amas = Amas(environment)
        amas.set_execution_policy(ExecutionPolicy.TWO_PHASES)

        agent = Agent(amas)
        self.assertEqual(agent.get_phase(), Phase.INITIALIZING)
        agent.run()
        self.assertEqual(agent.get_phase(), Phase.PERCEPTION_DONE)
        agent.run()
        self.assertEqual(agent.get_phase(), Phase.DECISION_AND_ACTION_DONE)


if __name__ == '__main__':
    main()
